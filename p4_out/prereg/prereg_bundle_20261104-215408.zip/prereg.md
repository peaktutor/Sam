# Preregistration: prediction P4 on the Allen Visual Behavior Neuropixels data

Prepared 04 November 2026, 21:54 Eastern Standard Time from the output folder of steps 1–2.

| Item | Value fixed in advance |
|---|---|
| Beta band | 15.00–30.00 Hz (no clear peak in 12–40 Hz, so the guide's fallback; 42 channel spectra; pilot mice only; band.json) |
| Pilot mice | 574082, 556014 |
| Test mice | 16, the first after the pilot mice in the seeded shuffle: 560962, 524925, 563497, 533537, 541234, 579993, 576324, 570301, 544358, 560356, 555304, 577287, 524761, 578257, 548721, 570302 |
| Channels | visual cortex (VISp, VISl, VISal, VISrl, VISam, VISpm), every second channel of those in the LFP file (1 probe per session); driven if the evoked potential at 30–100 or 100–200 ms differs from baseline (p < 0.0005 each, paired t test across flashes) |
| Flashes | task block, omitted flashes excluded; windows during 50–250 ms, after 300–550 ms, before −250–0 ms |
| Beta measure | induced envelope: each condition's mean evoked potential removed, 4th-order Butterworth band-pass, Hilbert amplitude, normalized to the channel's median |
| Novelty contrast (primary) | novel sessions: flashes from the 2nd to the first 20% minus the last 40% |
| Units and tests | mice; one-sample two-sided t tests, α = 0.05 |
| Decision rule | reset-driven if the timing index and the novelty contrast are both significantly positive; rebound-driven if the timing index is significantly negative and the novelty contrast is not significantly positive; otherwise inconclusive. A reversal of a predicted sign counts as disconfirmation. |
| Sample size | 16 test mice. The model recovery needed 8 sessions to recover the reset-driven reading at full signal and 16 at half signal; the rebound-driven reading needed 3. |
| Code | vbn_p4.py exactly as run, SHA-256 fc7e126cd408f409adfa9732ae4ec6d79efffb3168b59e4015eb6f141cd0fedd |

## Changes from the script in the guide (Appendix A)

All made on the pilot mice, before any test mouse was analysed:

- The channel table column is `ecephys_probe_id` in AllenSDK 2.16.2 (the script crashed on the real files).
- The Welch window is rounded rather than truncated: probe clocks differ slightly from 1250 Hz, which gave spectra of unequal length (the script crashed on the real files).
- The test set is the first 16 mice after the pilot mice in the seeded shuffle, as the sample size above requires; the script had taken all 47.
- Every second channel is taken among the channels the LFP file holds. Real LFP files keep every 4th channel, and subsampling first kept as few as 3 of 19 recorded visual channels on a probe.
- A clear peak must stand 0.05 (log10) above the 1/f fit and above its surroundings after 4 Hz smoothing. The old rule took the highest point in 12–40 Hz, which on the pilot data was the 40 Hz edge of a spectrum rising into gamma, not a peak.
- In the hazard estimate, a change flash counts as one more than the flash before it. AllenSDK numbers every change flash 0, which gave every non-change flash but the first a hazard of 0.
- Added: the novelty contrast on the two shared images, as a control, and a report of reversals of a predicted sign. Neither changes the decision rule.

## Checksums (SHA-256)

- `vbn_p4.py`: `fc7e126cd408f409adfa9732ae4ec6d79efffb3168b59e4015eb6f141cd0fedd`
- `band.json`: `1a82e6a0ee1074ba5cd36c47bc460991bd66596c76327d2d33c1f46743c1d5a9`
- `split.json`: `bd11a97400a29cb537f8420129e67959030826dd2875b150b3943f3a44bde691`
